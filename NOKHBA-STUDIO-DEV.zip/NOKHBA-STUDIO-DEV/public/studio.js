(() => {
  "use strict";
  // Empty by design until a separate DEV Worker URL is configured.
  const DEV_WORKER_URL = "";
  const button = document.getElementById("healthButton");
  const title = document.getElementById("healthTitle");
  const detail = document.getElementById("healthText");
  const dot = document.getElementById("healthDot");

  button.addEventListener("click", async () => {
    if (!DEV_WORKER_URL) {
      title.textContent = "Worker التطوير غير مُعدّ بعد";
      detail.textContent = "لم نضع عنواناً للخادم عمداً. لن يتم إرسال أي طلب إلى موقع الإنتاج.";
      dot.className = "dot idle";
      return;
    }
    button.disabled = true;
    title.textContent = "جارٍ الفحص...";
    detail.textContent = "يتم الاتصال بعنوان بيئة التطوير المحدد فقط.";
    try {
      const response = await fetch(`${DEV_WORKER_URL}/health`, { method: "GET", cache: "no-store" });
      const data = await response.json();
      if (!response.ok || data.status !== "ok") throw new Error("Health check failed");
      title.textContent = "Worker التطوير متصل";
      detail.textContent = `الإصدار: ${data.version || "غير محدد"}`;
      dot.className = "dot ok";
    } catch {
      title.textContent = "تعذر الاتصال بـ Worker التطوير";
      detail.textContent = "راجع إعدادات بيئة التطوير وسجلات الخادم.";
      dot.className = "dot bad";
    } finally {
      button.disabled = false;
    }
  });
})();
